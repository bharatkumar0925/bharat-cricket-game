# bowlers.py

import random
from cricket_computer_prediction import prediction

def bowlers_choose():
# Initialise the bowler dictionary and choose the random bowler
    n = 13
    total_bowlers = {'bhuvneshwar kumar': prediction(n), 'kuldeep yadav': prediction(n), 'jasprid bumra': prediction(n)}
    bowler = random.choice(list(total_bowlers.keys()))
    return total_bowlers,bowler



def bowler_change(total_bowlers, bowler, bowlers_detail, balls):
    over_limit = 2.0
    if balls % 6 == 0:
        while True:
            previous_bowler = bowler
            bowler = random.choice(random.sample(list(total_bowlers.keys()), 1))

            if bowler == previous_bowler or float(bowlers_detail[bowler]['overs']) > over_limit:
                continue
            else:
                break
        print(f'Next bowler: {bowler}')
    return bowler


total_bowlers, _ = bowlers_choose()
def bowling_card(total_bowlers=total_bowlers):
    bowlers_detail = {
        bowler: {'overs': 0, 'runs': 0, 'wickets': 0, 'eco': 0, 'balls': 0} for bowler in total_bowlers
    }
    return bowlers_detail


def bowler_show(bowler, bowlers_detail):
    bowler_detail = list(bowlers_detail[bowler].values())
    bowler_detail.remove(bowler_detail[-1])
    print(f'{bowler}: {bowler_detail}')

def bowlers_show(total_bowlers, bowlers_detail):
    print('Bowling card: O, R, W, ER')
    for bowlers in total_bowlers:
        bowler_detail = list(bowlers_detail[bowlers].values())
        bowler_detail.remove(bowler_detail[-1])
        overs_bowled = float(bowler_detail[0])  # Get the number of overs bowled
        if overs_bowled > 0:
            print(f'{bowlers}: {bowler_detail}')
