# batsmen.py

import random

def batters_info(wickets):
    batsmen_list = ['rohit sharma', 'shicker dhawan', 'virat kohli', 'soorray kumar yadav', 'rishabh pant', 'sanju samson', 'shrayesh aiyer', 'ms dhoni', 'hardik pandya', 'rinku singh', 'jitesh sharma', 'dhruv jurel']
    batsmen_index = list(random.sample(range(0, len(batsmen_list)), wickets+1))
    batsmen_index.sort()
    batsmen = [batsmen_list[i] for i in batsmen_index]
    batting_card = {batsman: {'runs': 0, 'balls': 0} for batsman in batsmen}
    return batsmen, batting_card


def batsmen_shows(current_batsman, player_scores):
    print('Batting card:')
    for batter, details in player_scores.items():
        player_detail = list(details.values())
        batters_balls = player_detail[-1]
        if batter in current_batsman or batters_balls > 0:
            print(f'{batter}: {player_detail}')
