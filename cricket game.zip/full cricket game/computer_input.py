import pandas as pd
import random
from cricket_sound import main_audio



match_id = 1
def load_data():
    try:
        existing_data = pd.read_csv('match_data.csv')
        return existing_data
    except FileNotFoundError:
        existing_data = pd.DataFrame(columns=['Match_id', 'User', 'Computer', 'Is_wicket', 'Required', 'Balls', 'Wicket left'])
    return existing_data

def save_to_csv(data):
    existing_data = load_data()

    if isinstance(data, list):
        data_dict = {
            'Match_id': data[6],
            'User': data[0],
            'Computer': data[1],
            'Is_wicket': data[2],
            'Required': data[3],
            'Balls': data[4],
            'Wicket left': data[5]
        }
        new_row = pd.DataFrame([data_dict], columns=existing_data.columns)
        combined_data = pd.concat([existing_data, new_row], ignore_index=True)
        combined_data.to_csv('match_data.csv', index=False)
    else:
        print("Invalid data format. Expected list.")


def get_user_input():
    while True:
        try:
            user = int(input('Enter the number: '))
            if user < 0 or user > 6:
                print('Please enter a number between 0 and 6.')
            else:
                return user
        except ValueError:
            main_audio('C:/Users/BHARAT/Desktop/my files/sounds/effects/invalidSelection.mp3')
            print('Invalid input. Please enter a number between 0 and 6.')

