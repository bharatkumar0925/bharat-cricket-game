import random
import time
import pandas as pd
from cricket_score_generation import generate_game_params
from cricket_sound import play_background_music, main_audio
from cricket_condition_sound import condition_sound, conditional_volume
from bowlers import bowlers_choose, bowler_change, bowler_show, bowlers_show, bowling_card
from batsmen import batters_info, batsmen_shows
from computer_input import save_to_csv, get_user_input

def match_id():
    try:
        df = pd.read_csv('match_data.csv')
        match_id = df['Match_id'].iloc[-1]
        match_id = match_id + 1
    except FileNotFoundError:
        match_id = 1
    return match_id

def print_game_stats(required, balls, wickets, eco):
    print(f"Require: {required}, Balls: {balls}, \n Economy: {eco}, \n Wickets: {wickets}")

def game():
    required, balls, wickets, eco = generate_game_params()
    print_game_stats(required, balls, wickets, eco)

    players, player_scores = batters_info(wickets)

    # Initialize current_batsman with the first two players
    current_batsman = [players.pop(0), players.pop(0)]

    # Initialise the bowler dictionary and choose the random bowler
    total_bowlers, bowler = bowlers_choose()

    # Initialize bowlers_detail dictionary
    bowlers_detail = bowling_card()
    print(f'{current_batsman[0]} and {current_batsman[1]} are coming on the crease. \n Remaining batsmen are: {players} \n {current_batsman[0]} has the strike and {bowler} starts the attack.')

    partnership = 0
    partnership_balls = 0
    id = match_id()
    total = 0
    play_background_music('C:/Users/BHARAT/Desktop/my files/sounds/musics/IPL.mp3', volume=30)

    while True:
        total_bowlers, _ = bowlers_choose()
        current_bowler = total_bowlers[bowler]
        bowler_show(bowler, bowlers_detail)
        user = get_user_input()
        computer = current_bowler
        is_wicket = computer == user
        entry = [user, computer, is_wicket, required, balls, wickets, id]
        save_to_csv(entry)
        condition_sound(user, computer, required, total)
        current_strike = current_batsman[0]

        if is_wicket:
            wickets -= 1
            balls -= 1
            print(f'Partnership: {partnership} in {partnership_balls + 1} balls')
            partnership = partnership_balls = 0
            bowlers_detail[bowler]['wickets'] += 1
            bowlers_detail[bowler]['balls'] += 1
            ball     = bowlers_detail[bowler]['balls']
            overs = f'{ball//6}.{ball%6}'
            bowlers_detail[bowler]['eco'] = round((bowlers_detail[bowler]['runs']*6)/ball, 2)
            bowlers_detail[bowler]['overs'] = overs
            player_scores[current_strike]['balls'] += 1

            player_out_score = player_scores[current_strike]['runs']
            player_balls_played = player_scores[current_strike]['balls']
            print(f'{current_strike} is out on {player_out_score} runs in {player_balls_played} balls')

            if wickets > 0:
                current_batsman.remove(current_strike)
                # Add the next batsman to the list of current batsmen from the players list
                next_batsman = players.pop(0)
                current_batsman.insert(0, next_batsman)
                print(f'Wickets left: {wickets}, Required: {required}, Balls {balls}')
                print(f'Next batsman is: {next_batsman}')
                if balls % 6 == 0:
                    current_batsman.reverse()

        else:
            required -= user
            balls -= 1
            total += user
            print(total)
            partnership += user
            partnership_balls += 1
            print(f'Partnership: {partnership} in {partnership_balls} balls')
            bowlers_detail[bowler]['balls'] += 1
            bowlers_detail[bowler]['runs'] += user
            ball = bowlers_detail[bowler]['balls']
            overs = f'{ball//6}.{ball%6}'
            bowlers_detail[bowler]['overs'] = overs
            bowlers_detail[bowler]['eco'] = round((bowlers_detail[bowler]['runs']*6/ball), 2)
            player_scores[current_strike]['runs'] += user
            player_scores[current_strike]['balls'] += 1

                # Rotate the strike between the two remaining players
            if user in [1, 3] and balls % 6 != 0:
                current_batsman.reverse()
            elif balls % 6 == 0 and user not in [1, 3]:
                current_batsman.reverse()

            print(f'{current_batsman[0]} is playing on {player_scores[current_batsman[0]]["runs"]} runs in {player_scores[current_batsman[0]]["balls"]} balls'
                  f' and {current_batsman[1]} is playing on {player_scores[current_batsman[1]]["runs"]} runs in {player_scores[current_batsman[1]]["balls"]} balls')
            if required > 0 and balls > 0:
                print(f'Required: {required}, Balls: {balls}, Economy: {round((required / balls) * 6, 2)}, Wickets: {wickets}')
            print(f'{bowler}: {computer} and {current_strike}: {user}')

        if required <= 0 or wickets <= 0 or balls <= 0:
            if required <= 0:
                main_audio('C:/Users/BHARAT/Desktop/my files/sounds/musics/free-crowd-cheering-sounds-02-strong-cheering-rhythmic-cheering-116190.mp3')
                main_audio('C:/Users/BHARAT/Desktop/my files/sounds/effects/positive1.mp3')
                print(f'You won the game! by {wickets} wickets with {balls} balls remaining')
            elif required == 1:
                print('Game tied.')
            elif balls <= 0:
                main_audio('C:/Users/BHARAT/Desktop/my files/sounds/effects/sadGameOver.wav')
                print(f'You cannot chase the target, You lose the game by {required - 1} runs. Good luck for future matches!')
            else:
                main_audio("C:/Users/BHARAT/Desktop/my files/sounds/effects/negative_beeps-6008.mp3")
                print(f'You lost the game by {required - 1} runs. You lose all your wickets.')
                time.sleep(10)
            break
        conditional_volume(required, balls, wickets, is_wicket)
        bowler = bowler_change(total_bowlers, bowler, bowlers_detail, balls)

    batsmen_shows(current_batsman, player_scores)
    bowlers_show(total_bowlers, bowlers_detail)

game()
