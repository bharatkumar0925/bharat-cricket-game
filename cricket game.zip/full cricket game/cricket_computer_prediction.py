import random
import pandas as pd
import numpy as np
from sklearn.neighbors import KNeighborsClassifier

def prediction(k=19):
    data = pd.read_csv('match_data.csv')
    data['psp'] = data.groupby(['Match_id', 'Wicket left'])['User'].cumsum()
    data.loc[data['Is_wicket'] == True, 'psp'] = 0

    data = data.drop('Match_id', axis=1)


    data['Economy'] = (data['Required'].div(data['Balls'])*6).round(2)
    economy_edges = [0, 12, 24, np.inf]
    economy_levels = [0, 1, 2]
    data['is high economy'] = pd.cut(data['Economy'], bins=economy_edges, labels=economy_levels)

    data['is high economy'] = data['is high economy'].shift(-1)

    data = data.drop('Economy', axis=1)
    data['cons'] = data['User'] == data['User'].shift(-1)
    strike = [
        ((data['User'].isin([1, 3])) & (data['Balls']-1%6 != 0) | (data['User'].isin([2, 4, 5, 6])) & (data['Balls']-1%6 == 0)),
        data['Is_wicket'] == True
    ]
    strike_condition = [1, 2]
    data['is_strike'] = np.select(strike, strike_condition, default=0)

    is_big = [data['User'] >= 4]
    choice = [1]
    data['Is_big'] = np.select(is_big, choice, default=0)
    data['Next big'] = data['Is_big'].shift(-1)
    data['Next user'] = data['User'].shift(-1)
    data.dropna(inplace=True)
    data = data.astype({'User': 'int8', 'Computer': 'int8', 'Required': 'int16', 'Balls': 'int8', 'Wicket left': 'int8', 'is_strike': 'bool', 'Is_big': 'bool', 'Next big': 'bool', 'Next user': 'int8'})
    df = data.drop('Next user', axis=1).iloc[-1]

    # Define the split index as 60% of the data length
    split_index = int(0.95 * len(data))

    # Split the data into training and testing sets
    x_train = data.iloc[:split_index, :-1].values
    y_train = data['Next user'][:split_index].values
    x_test = data.iloc[split_index:, :-1].values
    y_test = data['Next user'][split_index:].values
    knn_classifier = KNeighborsClassifier(n_neighbors=k, weights='distance')
    knn_classifier.fit(x_train, y_train)

    array = np.array(df).reshape(1, -1)
    predict = knn_classifier.predict(array)
    return int(predict)


