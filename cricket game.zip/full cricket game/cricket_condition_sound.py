# cricket_condition_sound.py

import pygame
from cricket_sound import main_audio, play_background_music

def condition_sound(user, computer, require, total):
    path = 'C:/Users/BHARAT/Desktop/my files/sounds/effects/'
    if user != computer:
        main_audio(path+'cricket_match1.mp3', threading_apply=False)
    if user >= 4 and user != computer:
        main_audio(path+'cricket_match2.mp3')
        if require <= total//2:
            main_audio(path+'cricket_match3.mp3')
    elif user <= 3 and user != computer:
        main_audio(path+'cricket_match4.mp3')
    if user == computer:  # User gets out
        if require <= total:
            main_audio(path+'wicket4.mp3')
        else:
            main_audio(path + 'wicket3.mp3')
    else:  # User makes a batting choice
        if user == 1:
            main_audio(path + 'bat1.mp3')
        elif user == 2:
            main_audio(path + 'bat2.mp3')
        elif user == 3:
            main_audio(path + 'bat3.mp3')
        elif user == 4:
            main_audio(path + 'bat4.mp3')
        elif user == 5:
            main_audio(path + 'bat5.mp3')
        elif user == 6:
            if require <= 25 and user == 6:
                main_audio(path+'bat6_consecutive.mp3')
            else:
                main_audio(path + 'bat6.mp3')
        else:
            pass



def conditional_volume(required, balls, wickets, is_wicket):
# Adjust volume conditionally
    if required <= 0:
        pygame.mixer.music.set_volume(1.0)
    elif balls == 0 or wickets == 0:
        pygame.mixer.music.set_volume(0.6)
    elif balls % 6 == 0 or is_wicket == True:
        pygame.mixer.music.set_volume(0.45)
    else:
        pygame.mixer.music.set_volume(0.2)
